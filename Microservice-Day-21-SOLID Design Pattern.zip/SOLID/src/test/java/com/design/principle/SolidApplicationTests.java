package com.design.principle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolidApplicationTests {

	@Test
	void contextLoads() {
	}

}
