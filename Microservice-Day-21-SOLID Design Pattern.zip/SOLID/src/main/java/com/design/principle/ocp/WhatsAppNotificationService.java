package com.design.principle.ocp;

public class WhatsAppNotificationService implements NotificationService {

	@Override
	public void sendOTP(String medium) {
		// logic to integrate WhatsApp Api
		
	}

	@Override
	public void sendTransactionReport(String medium) {
		// logic to integrate WhatsApp Api
		
	}

}
