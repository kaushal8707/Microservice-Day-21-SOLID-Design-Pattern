package com.design.principle.isp;

public interface UPIPayments {

    public void payMoney();

    public void getScratchCard();
    
    public void getCashBackAsCreditBalance();


}
